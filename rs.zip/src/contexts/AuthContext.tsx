import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import { differenceInDays, parseISO } from 'date-fns';
import { sendPasswordResetEmail } from '../lib/brevo';
import { passwordResetService } from '../lib/passwordResetService';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // 1. Verificação do estado de autenticação e sessão expirada
  useEffect(() => {
    const checkSessionExpiration = () => {
      const loginTime = localStorage.getItem('loginTime');
      const maxSessionDuration = 20 * 60 * 1000; // 20 minutos em milissegundos

      if (loginTime) {
        const timeElapsed = new Date().getTime() - Number(loginTime);

        if (timeElapsed > maxSessionDuration) {
          // Faz o logout se a sessão expirou
          supabase.auth.signOut();
          localStorage.removeItem('loginTime');
          setUser(null); // Reseta o estado de usuário
          toast.error('Sua sessão expirou. Por favor, faça login novamente.');
          return;
        }
      }
    };

    // Verifica a sessão ao carregar o estado inicial
    supabase.auth.getSession().then(({ data: { session } }) => {
      checkSessionExpiration(); // Checa expiração no primeiro load
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Escutar mudanças no estado de autenticação
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      checkSessionExpiration(); // Checa expiração quando o estado muda
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe(); // Limpa o listener ao desmontar
  }, []);

  // 2. Login do usuário (salva horário de login)
  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error || !data.user) throw error || new Error('Usuário não encontrado');

      // Salvar horário de login
      localStorage.setItem('loginTime', JSON.stringify(new Date().getTime()));

      setUser(data.user); // Atualiza o estado de usuário
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      }
      throw error;
    }
  };

  // 3. Cadastro de usuário
  const signUp = async (name: string, email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name: name,
          },
        },
      });

      if (error || !data.user) throw error || new Error('Erro ao criar conta');

      toast.success('Conta criada com sucesso!');
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('Erro ao criar conta. Tente novamente.');
      }
      throw error;
    }
  };

  // 4. Logout (limpa horário de login)
  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      localStorage.removeItem('loginTime'); // Remove o horário de login
      setUser(null); // Reseta o estado de usuário
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      }
      throw error;
    }
  };

  // 5. Reset de senha (versão modificada)
  const resetPassword = async (email: string) => {
    try {
      // Gerar token de reset
      const token = await passwordResetService.createResetToken(email);
      
      // Criar link de reset
      const resetLink = `${window.location.origin}/reset-password?token=${token}`;
      
      // LOG PARA DESENVOLVIMENTO
      console.log('===============================');
      console.log('LINK DE RECUPERAÇÃO DE SENHA (APENAS PARA DESENVOLVIMENTO):');
      console.log(resetLink);
      console.log('===============================');
      
      // Enviar email usando Brevo
      await sendPasswordResetEmail(email, resetLink);

      toast.success('Email de recuperação enviado! Verifique sua caixa de entrada e também o console do navegador (durante desenvolvimento).');
    } catch (error) {
      console.error('Erro ao enviar email de recuperação:', error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('Erro ao enviar email de recuperação');
      }
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook para consumir o contexto
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}